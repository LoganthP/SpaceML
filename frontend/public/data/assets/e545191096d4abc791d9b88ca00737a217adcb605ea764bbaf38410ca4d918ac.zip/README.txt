Evidence bundle for run b1a11e9a112d (telemetry) - origin: computed.
manifest.json: data source + hashes, data window, model version + file hashes, settings, baseline,
metrics, reviewer notes and software versions. report.md: human-readable summary.
To repeat: open the run in Space ML Mission Control and press 'Repeat run', or
POST /api/runs/b1a11e9a112d/repeat ; then GET /api/runs/<new id>/reproducibility.
