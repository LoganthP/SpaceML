Evidence bundle for run 5cb7ec71228f (telemetry) - origin: computed.
manifest.json: data source + hashes, data window, model version + file hashes, settings, baseline,
metrics, reviewer notes and software versions. report.md: human-readable summary.
To repeat: open the run in Space ML Mission Control and press 'Repeat run', or
POST /api/runs/5cb7ec71228f/repeat ; then GET /api/runs/<new id>/reproducibility.
