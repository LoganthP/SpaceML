Evidence bundle for run ca526de58c9f (telemetry) - origin: computed.
manifest.json: data source + hashes, data window, model version + file hashes, settings, baseline,
metrics, reviewer notes and software versions. report.md: human-readable summary.
To repeat: open the run in Space ML Mission Control and press 'Repeat run', or
POST /api/runs/ca526de58c9f/repeat ; then GET /api/runs/<new id>/reproducibility.
