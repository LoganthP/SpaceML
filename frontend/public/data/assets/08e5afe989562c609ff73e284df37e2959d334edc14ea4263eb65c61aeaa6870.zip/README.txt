Evidence bundle for run ref-de7ff02d36 (telemetry) - origin: bundled.
manifest.json: data source + hashes, data window, model version + file hashes, settings, baseline,
metrics, reviewer notes and software versions. report.md: human-readable summary.
To repeat: open the run in Space ML Mission Control and press 'Repeat run', or
POST /api/runs/ref-de7ff02d36/repeat ; then GET /api/runs/<new id>/reproducibility.
