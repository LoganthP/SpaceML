Evidence bundle for run c61e52ba32df (telemetry) - origin: computed.
manifest.json: data source + hashes, data window, model version + file hashes, settings, baseline,
metrics, reviewer notes and software versions. report.md: human-readable summary.
To repeat: open the run in Space ML Mission Control and press 'Repeat run', or
POST /api/runs/c61e52ba32df/repeat ; then GET /api/runs/<new id>/reproducibility.
