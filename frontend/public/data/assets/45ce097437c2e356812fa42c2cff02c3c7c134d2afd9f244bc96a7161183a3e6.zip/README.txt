Evidence bundle for run 33a3fe3bd78c (telemetry) - origin: computed.
manifest.json: data source + hashes, data window, model version + file hashes, settings, baseline,
metrics, reviewer notes and software versions. report.md: human-readable summary.
To repeat: open the run in Space ML Mission Control and press 'Repeat run', or
POST /api/runs/33a3fe3bd78c/repeat ; then GET /api/runs/<new id>/reproducibility.
