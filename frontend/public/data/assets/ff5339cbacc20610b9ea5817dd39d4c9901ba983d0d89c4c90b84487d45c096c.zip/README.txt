Evidence bundle for run e9be04600d0c (telemetry) - origin: computed.
manifest.json: data source + hashes, data window, model version + file hashes, settings, baseline,
metrics, reviewer notes and software versions. report.md: human-readable summary.
To repeat: open the run in Space ML Mission Control and press 'Repeat run', or
POST /api/runs/e9be04600d0c/repeat ; then GET /api/runs/<new id>/reproducibility.
